
from tkinter import *

root=Tk()
#root.iconphoto(True, PhotoImage(file="calculator.png"))

master=Frame(root)
master.config(bg="Firebrick4")

master.pack()

expresion=""
reset_screen=False
resultado=0
num1=0
cont_resta=0
cont_mult=0
cont_div=0

#-------------Pantalla---------------

numeroPantalla=StringVar()
pantalla=Entry(master, textvariable=numeroPantalla)
pantalla.grid(row=1, column=1, padx="10", pady="10", columnspan="4")
pantalla.config(bg="gray10", fg="snow", justify="right")

#-------------Funciones---------------

def numeroPulsado(num):
    global expresion
    global reset_screen
   
    if reset_screen!=False:

        numeroPantalla.set(num)

        reset_screen=False

    else: 

        numeroPantalla.set(numeroPantalla.get() + num)    

def Suma(num):

    global expresion 
    global resultado
    global reset_screen
    resultado+=float(num)
    expresion="Suma"
    reset_screen=True
    numeroPantalla.set(resultado)

def Resta(num):

    global expresion
    global resultado
    global cont_resta
    global num1
    global reset_screen

    if cont_resta==0:

        num1=float(num)
        resultado=num1

    else:

        if cont_resta==1:

            resultado=num1-float(num)  

        else:

            resultado=float(resultado)-float(num)

        numeroPantalla.set(resultado)
        resultado=numeroPantalla.get()
        
    cont_resta=cont_resta+1

    expresion="Resta"

    reset_screen=True

def Multiplicación(num):

	global expresion
	global resultado
	global num1
	global cont_mult
	global reset_screen

	if cont_mult==0:

		num1=float(num)
		resultado=num1

	else:

		if cont_mult==1:

			resultado=num1*float(num)

		else:

			resultado=float(resultado)*float(num)	

		numeroPantalla.set(resultado)
		resultado=numeroPantalla.get()

	cont_mult=cont_mult+1
	expresion="Multiplicación"
	reset_screen=True

def División(num):

	global expresion
	global resultado
	global num1
	global cont_div
	global reset_screen

	if cont_div==0:

		num1=float(num)
		resultado=num1

	else:

		if cont_div==1:

			resultado=num1/float(num)
            
		else:

			resultado=float(resultado)/float(num)	

		numeroPantalla.set(resultado)
		resultado=numeroPantalla.get()

	cont_div=cont_div+1
	expresion="División"
	reset_screen=True
    
def Clear():

    global expresion
    numeroPantalla.set("")

def Delete():

    global expresion
    global resultado
    global num1
    global cont_resta
    global cont_mult
    global cont_div
    
    numeroPantalla.set("")
    resultado=0
    num1=0
    cont_resta=0
    cont_mult=0
    cont_div=0

def Igual():

    global resultado
    global expresion
    global cont_resta
    global cont_mult
    global cont_div

    if expresion=="Suma":

        numeroPantalla.set(resultado+float(numeroPantalla.get()))

        resultado=0

    elif expresion=="Resta":

        numeroPantalla.set(resultado-float(numeroPantalla.get()))  

        resultado=0

        cont_resta=0

    elif expresion=="Multiplicación":

        numeroPantalla.set(float(resultado)*float(numeroPantalla.get()))
        
        resultado=0

        cont_mult=0

    elif expresion=="División":

        numeroPantalla.set(float(resultado)/float(numeroPantalla.get()))
        
        resultado=0
        
        cont_div=0     

#-------------Fila 1-----------------

botonC=Button(master, text="C", width=3, command=Clear)
botonC.grid(row=2, column=1)
botonDiv=Button(master, text="/", width=3, command=lambda:División(numeroPantalla.get()))
botonDiv.grid(row=2, column=2)
botonMult=Button(master, text="X", width=3, command=lambda:Multiplicación(numeroPantalla.get()))
botonMult.grid(row=2, column=3)
botonErase=Button(master, text="Del", width=3, command=Delete)
botonErase.grid(row=2, column=4)

#-------------Fila 2-----------------

boton7=Button(master, text="7", width=3, command=lambda:numeroPulsado("7"))
boton7.grid(row=3, column=1)
boton8=Button(master, text="8", width=3, command=lambda:numeroPulsado("8"))
boton8.grid(row=3, column=2)
boton9=Button(master, text="9", width=3, command=lambda:numeroPulsado("9"))
boton9.grid(row=3, column=3)
botonSuma=Button(master, text="+", width=3, command=lambda:Suma(numeroPantalla.get()))
botonSuma.grid(row=3, column=4)

#-------------Fila 3--------------------

boton4=Button(master, text="4", width=3, command=lambda:numeroPulsado("4"))
boton4.grid(row=4, column=1)
boton5=Button(master, text="5", width=3, command=lambda:numeroPulsado("5"))
boton5.grid(row=4, column=2)
boton6=Button(master, text="6", width=3, command=lambda:numeroPulsado("6"))
boton6.grid(row=4, column=3)
botonResta=Button(master, text="-", width=3, command=lambda:Resta(numeroPantalla.get()))
botonResta.grid(row=4, column=4)

#-------------Fila 4--------------------

boton1=Button(master, text="1", width=3, command=lambda:numeroPulsado("1"))
boton1.grid(row=5, column=1)
boton2=Button(master, text="2", width=3, command=lambda:numeroPulsado("2"))
boton2.grid(row=5, column=2)
boton3=Button(master, text="3", width=3, command=lambda:numeroPulsado("3"))
boton3.grid(row=5, column=3)
botonIgual=Button(master, text="=", width=3, height=2, command=lambda:Igual())
botonIgual.grid(row=5, column=4, rowspan=2)

#-------------Fila 5--------------------

botonPorcen=Button(master, text="%", width=3)
botonPorcen.grid(row=6, column=1)
boton0=Button(master, text="0", width=3, command=lambda:numeroPulsado("0"))
boton0.grid(row=6, column=2)
botonComa=Button(master, text=",", width=3, command=lambda:numeroPulsado("."))
botonComa.grid(row=6, column=3)

root.mainloop()